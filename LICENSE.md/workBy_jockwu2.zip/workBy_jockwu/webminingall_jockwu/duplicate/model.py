# -*- coding: utf-8 -*-

from simhash import simhash
import re
from pattern import pattern
import ctypes
import msvcrt




def load_data(filepath1 = '../dataset_if_valid/valid_g_withouthtml_badcase.txt', filepath2 = '../dataset_if_valid/valid_g_withouthtml_badcase.txt' ):
    result = []
    with open(filepath1,'rb') as f:
        line = '1'
        num = 0
        while line:
            num += 1
            line = f.readline().decode('utf-8').replace('\n','').replace('\r','')
            result.append(line)
            if num==3000:
                break
    return result

def handle_Bysimhash(data_list):
    min = 9
    max = 10
    high = 0
    mid = 0
    low = 0
    length = len(data_list)
    f_high = open('./duplicate_case/simhash_h.txt','w',encoding='utf-8')
    f_mid = open('./duplicate_case/simhash_m.txt','w',encoding='utf-8')
    f_low = open('./duplicate_case/simhash_l.txt','w',encoding='utf-8')
    simhash_dict = {}
    for i in range(length):
        simhash_dict[i] = simhash(data_list[i].split('\t')[1],hashsize=128,keyword_size=100)
    num = 0
    for i in range(length):
        num += 1
        if num%100 ==0:
            print (num)
        #print (min,data1,data2)
        for j in range(i+1,length):
            if simhash_dict[i].hammingDis(simhash_dict[j])<min:
                f_high.write(data_list[i]+'\n')
                f_high.write(data_list[j]+'\n')
                f_high.write('\n')
                high += 1
            elif simhash_dict[i].hammingDis(simhash_dict[j])<=max:
                f_mid.write(data_list[i]+'\n')
                f_mid.write(data_list[j]+'\n')
                f_mid.write('\n')
                mid += 1
            else:
                low += 1
    f_mid.close()
    f_high.close()
    f_low.close()
    print (high,mid,low)

def test_simhash():
    content1 = '金山网讯 昨天，记者从市运管部门了解到，谏壁雩山街拓宽改造工程已完工，具备通行条件，市公交公司将从10月18日起恢复谏壁雩山街路段通行，公交9路、28路、72路、209路、211路从这一时段起将按原线行驶。72路恢复后线路走向为谏壁公交站-龙山；恢复停靠雩山街北站、燕舞桥、月湖街共3对站点，往谏壁公交站方向恢复下虞1个单向站点；撤销六九零四、莺歌桥2对临时站点。211路恢复后线路走向为行政中心公交站-姚桥公交站；恢复停靠长岗、索普集团、化工开发区、纸浆厂、正兴学校、雩山街北站、燕舞桥、月湖街共8对站点，撤销金港大道上的1对月湖街临时站点。（吴泽平 韩超 沈湘伟）'
    content2 = '随着谏壁雩山街拓宽改造工程具备通行条件，市公交公司将从18日起，在谏壁雩山街路段恢复公交9路、28路、72路、209路、211路原线行驶，原线路首末班时间及大致行车间隔保持不变。 　　72路恢复线路走向后，恢复停靠雩山街北站、燕舞桥、月湖街共3对站点，往谏壁公交站方向恢复下虞1个单向站点；撤销六九零四、莺歌桥2对临时站点。 　　211路恢复线路走向后，恢复停靠长岗、索普集团、化工开发区、纸浆厂、正兴学校、雩山街北站、燕舞桥、月湖街共8对站点，撤销金港大道上的1对月湖街临时站点。'
    simhash1 = simhash(content1,hashsize=128,keyword_size=100)
    simhash2 = simhash(content2,hashsize=128,keyword_size=100)
    return simhash1.hammingDis(simhash2)

#返回最长公共子序列长度和序列串
def lcs_dp(s1, s2):
     # 生成字符串长度加1的0矩阵，m用来保存对应位置匹配的结果
    m = [ [ 0 for x in range(len(s2)+1) ] for y in range(len(s1)+1) ]
    # d用来记录转移方向
    d = [ [ None for x in range(len(s2)+1) ] for y in range(len(s1)+1) ]
    max_len = 0
    for p1 in range(len(s1)):
        for p2 in range(len(s2)):
            if s1[p1] == s2[p2]:            #字符匹配成功，则该位置的值为左上方的值加1
                m[p1+1][p2+1] = m[p1][p2]+1
                d[p1+1][p2+1] = 'ok'
            elif m[p1+1][p2] > m[p1][p2+1]:  #左值大于上值，则该位置的值为左值，并标记回溯时的方向
                m[p1+1][p2+1] = m[p1+1][p2]
                d[p1+1][p2+1] = 'left'
            else:                           #上值大于左值，则该位置的值为上值，并标记方向up
                m[p1+1][p2+1] = m[p1][p2+1]
                d[p1+1][p2+1] = 'up'
    (p1, p2) = (len(s1), len(s2))
    max_len = m[p1][p2]
    #print numpy.array(d)
    s = []
    while m[p1][p2]:    #不为None时
        c = d[p1][p2]
        if c == 'ok':   #匹配成功，插入该字符，并向左上角找下一个
            s.append(s1[p1-1])
            p1-=1
            p2-=1
        if c =='left':  #根据标记，向左找下一个
            p2 -= 1
        if c == 'up':   #根据标记，向上找下一个
            p1 -= 1
    s.reverse()
    return max_len,''.join(s)

def handle_Bylcs(data_list):
    max = 0.8
    min = 0.6
    high = 0
    mid = 0
    low = 0
    length = len(data_list)
    f_high = open('./duplicate_case/lcs_h.txt','w',encoding='utf-8')
    f_mid = open('./duplicate_case/lcs_m.txt','w',encoding='utf-8')
    #f_low = open('./duplicate_case/lcs_l.txt','w',encoding='utf-8')
    num = 0
    for i in range(length):
        num += 1
        if num%100 ==0:
            print (num)
        #print (min,data1,data2)
        for j in range(i+1,length):
            _, word_comm = lcs_dp(data_list[i].split('\t')[0],data_list[j].split('\t')[0])
            lcs_smi = 2*len(word_comm)/(len(data_list[i].split('\t')[0])+len(data_list[j].split('\t')[0]))
            print (lcs_smi)
            print (word_comm)
            print (data_list[i].split('\t')[0])
            print (data_list[j].split('\t')[0])
            print ("**************************")
            if ord(msvcrt.getch()) in [68, 100]:
                exit(0)
            if lcs_smi>=max:
                f_high.write(data_list[i]+'\n')
                f_high.write(data_list[j]+'\n')
                f_high.write('\n')
                high += 1
            elif lcs_smi>=min:
                f_mid.write(data_list[i]+'\n')
                f_mid.write(data_list[j]+'\n')
                f_mid.write('\n')
                mid += 1
            else:
                low += 1
    f_mid.close()
    f_high.close()
    #f_low.close()
    print (high,mid,low)

def test_lcs():
    title1 = '香山红叶节公交专线本周六开通'
    title2 = '北京公交集团:香山红叶节公交专线本周六开通'
    len_comm,word_comm = lcs_dp(title1,title2)
    lcs_smi = 2*len_comm/(len(title1)+len(title2))
    return (word_comm,len_comm,lcs_smi)

def is_numorletter(s):
    for ch in s:
        if ch not in '1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM':
            return False
    return True

def handle_Bysimhashlcs(data_list):
    min = 9
    max = 10
    lcs_max = 0.85
    high = 0
    mid = 0
    low = 0
    sim_high = 0
    p = pattern()
    length = len(data_list)
    f_high = open('./duplicate_case/simhash_lcs_h.txt','w',encoding='utf-8')
    f_mid = open('./duplicate_case/simhash_notlcs_h.txt','w',encoding='utf-8')
    simhash_dict = {}
    for i in range(length):
        simhash_dict[i] = simhash(data_list[i].split('\t')[1],hashsize=128,keyword_size=100)
    num = 0
    for i in range(length):
        num += 1
        if num%100 == 0:
            print (num)
        #print (min,data1,data2)
        for j in range(i+1,length):
            sim_dis = simhash_dict[i].hammingDis(simhash_dict[j])
            if sim_dis < min :
                _, word_comm = lcs_dp(data_list[i].split('\t')[0],data_list[j].split('\t')[0])
                lcs_smi = 2*len(word_comm)/(len(data_list[i].split('\t')[0])+len(data_list[j].split('\t')[0]))
                del word_comm
                if lcs_smi >= lcs_max or (sim_dis<=3 and lcs_smi>=0.7):
                    #title 中公交车编号不一样，认为是不重复的
                    carid_same = p.compare(data_list[i].split('\t')[0],data_list[j].split('\t')[0])
                    if(carid_same):
                        f_high.write(data_list[i]+'\n')
                        f_high.write(data_list[j]+'\n')
                        f_high.write('\n')
                        high += 1
                        continue
                    print (data_list[i].split('\t')[0])
                    print (data_list[j].split('\t')[0])
                    print ("**************************")
                else:
                    f_mid.write(data_list[i]+'\n')
                    f_mid.write(data_list[j]+'\n')
                    f_mid.write('\n')
                    sim_high+=1
            elif simhash_dict[i].hammingDis(simhash_dict[j])<=max:
                mid += 1
            else:
                low += 1
    f_high.close()
    print (high,sim_high,mid,low)


datalist = load_data()
#handle_Bysimhash(datalist)
handle_Bylcs(datalist)
#handle_Bysimhashlcs(datalist)
#print (test_simhash())
#print (test_lcs())
