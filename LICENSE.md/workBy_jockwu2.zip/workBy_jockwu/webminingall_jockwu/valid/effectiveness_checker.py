# -*- coding: utf-8 -*-
"""
effectiveness_checker

Effectiveness checker is used to check whether a message is a useful one or a jam.

@author: edgarliao
@email: edgarliao@tencent.com
Created on 2017/9/6, please feel free to contact me.
"""
import pickle

from sklearn.externals import joblib
from sklearn.feature_extraction.text import TfidfTransformer

from jieba_count_vectorizer import JiebaCountVectorizer
from sklearn.preprocessing import StandardScaler


class EffectivenessChecker:

    def __init__(self, content_model_file, content_dict_file, scaler_dir, trans_dir):
        self.name = 'Effectiveness Checker'
        with open(content_dict_file, 'rb') as f:
            content_vacab = pickle.load(f)
        with open(scaler_dir+"content.scaler",'rb') as f:
            self.scaler_content = pickle.load(f)
        with open(trans_dir+"content.trans",'rb') as f:
            self.trans_content = pickle.load(f)
        self.content_count_vect = JiebaCountVectorizer(binary=False, vocabulary=content_vacab)
        self.content_clf = joblib.load(content_model_file)

    def predict_title(self, title, threshold=0.50):
        content_word_vec = self.title_count_vect.fit_transform([title])
        data_tf = self.trans_title.transform(content_word_vec).todense()
        data_tf_std = self.scaler_title.transform(data_tf)
        res = self.title_clf.predict_proba(data_tf_std)
        if res[0][1] > threshold:
            return 1
        else:
            return 0

    def predict_content(self, content, threshold=0.490):
        content_word_vec = self.content_count_vect.fit_transform([content])
        data_tf = self.trans_content.transform(content_word_vec).todense()
        data_tf_std = self.scaler_content.transform(data_tf)
        res = self.content_clf.predict_proba(data_tf_std)
        """
        if res[0][1] > threshold:
            return 1
        else:
            return 0
        """
        return res[0][1]

    def predict(self, content=''):
        #title_res = self.predict_title(title)
        content_res = 0
        content_res = self.predict_content(content)

        if content_res > 0.5:
            return 1,content_res
        else:
            return 0,content_res
