from distutils.core import setup, Extension
from Cython.Build import cythonize

setup(ext_modules = cythonize(Extension(
           "PyKeywordMatch",                                # the extension name
           sources=["PyKeywordMatch.pyx", "KeywordMatch.cpp"], # the Cython source and
           language="c++",                        # generate and compile C++ code
      )))
