# -*- coding: utf-8 -*-
"""
test_keyword_matcher


 
@author: edgarliao
@email: edgarliao@tencent.com
Created on 2018/4/2, please feel free to contact me.
"""

import sys
from PyKeywordMatch import PyKeywordMatch

reload(sys)
sys.setdefaultencoding('utf-8')

if __name__ == '__main__':
    print 'Begin test'
    keyword_matcher = PyKeywordMatch('/data/qqmap/infocollect/webmining_online/trunk/data/combined_keyword.csv')
    print 'Load data finished.'
    match_events = keyword_matcher.match_events(u'新建高速开通')
    for event in match_events:
        print event
