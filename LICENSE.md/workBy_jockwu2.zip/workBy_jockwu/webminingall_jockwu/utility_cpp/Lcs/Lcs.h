#ifndef LCS_H
#define LCS_H

#include<iostream>
#include<cstring>
#include<cstdlib>
using namespace std;

class Lcs
{
    public:
        Lcs();
        char* lcs_find(char *X, char *Y );
};

#endif