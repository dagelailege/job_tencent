#include "DuplicationChecker.h"
#include <fstream>

DuplicationChecker::DuplicationChecker()
{
    this->sim_hasher_ = new simhash::Simhasher("./dict/jieba.dict.utf8",
                                        "./dict/hmm_model.utf8",
                                        "./dict/idf.utf8",
                                        "./dict/stop_words.utf8");
    this->counter_.resize(101, vector<int>(101, 0));
}

DuplicationChecker::~DuplicationChecker()
{
    delete this->sim_hasher_;
}

DuplicationChecker& DuplicationChecker::operator=(const DuplicationChecker& checker)
{
    this->load_all_data(checker.hist_hash_file_names_, checker.current_hash_file_name_,
                        checker.hist_title_file_names_, checker.current_title_file_name_);
    return *this;
}

void DuplicationChecker::load_all_data(vector<string> hist_hash_files, string current_hash_file, vector<string> hist_title_files, string current_title_file)
{
    for (size_t i = 0; i < hist_hash_files.size(); ++i)
        this->load_hash_data(hist_hash_files[i]);
    this->load_hash_data(current_hash_file);

    for (size_t i = 0; i < hist_title_files.size(); ++i)
        this->load_title_data(hist_title_files[i]);
    this->load_title_data(current_title_file);

    current_hash_file_name_ = current_hash_file;
    hist_hash_file_names_ = hist_hash_files;
    current_title_file_name_ = current_title_file;
    hist_title_file_names_ = hist_title_files;
}

bool DuplicationChecker::check_lcs(string first, string second, float thre)
{
    int length_first = first.length();
    int length_second = second.length();
    int longest = 0;
    for (int i = 0; i < this->counter_.size(); ++i)
        this->counter_[i].assign(this->counter_[i].size(), 0);

    for (int i = 0; i < length_first; ++i)
        for (int j = 0; j < length_second; ++j)
        {
            if (first.at(i) == second.at(j))
                this->counter_[i + 1][j + 1] = this->counter_[i][j] + 1;
            else if (this->counter_[i + 1][j] > this->counter_[i][j + 1])
                this->counter_[i + 1][j + 1] = this->counter_[i + 1][j];
            else
                this->counter_[i + 1][j + 1] = this->counter_[i][j + 1];
            if (this->counter_[i + 1][j + 1] > longest)
                longest = this->counter_[i + 1][j + 1];
        }
    return ((float)longest * 2) / (first.length() + second.length()) >= thre ? true : false;
}

bool DuplicationChecker::check_similarity(string& title, string& content, float thre, int min_length, int max_length, int source)
{
    size_t title_top_n = 25;
    size_t content_top_n = 100;

    uint64_t title_hash = 0;
    uint64_t content_hash = 0;

    if (title.length() > 2)
    {
        this->sim_hasher_->make(title, title_top_n, title_hash);
    }

    if (content.length() > 10)
    {
        this->sim_hasher_->make(content, content_top_n, content_hash);
    }

    bool is_similar = false;
    if (source != 0)
    {
        for (size_t i = 0; i < this->title_hash_values_.size(); ++i)
        {
            if (content.length() > 10)
            {
                is_similar = this->content_hash_values_[i] == 0 ? false : simhash::Simhasher::isEqual(content_hash, this->content_hash_values_[i]);
            }
            else if (title.length() > 2)
            {
                is_similar = this->title_hash_values_[i] == 0 ? false : simhash::Simhasher::isEqual(title_hash, this->title_hash_values_[i], 0);
            }
            else
                is_similar = true;

            if (is_similar)
            {
                break;
            }
        }
    }

    if (!is_similar && title.length() > min_length && title.length() < max_length)
    {
        for (size_t i = 0; i < title_string_values_.size(); ++i)
        {
            if (title_string_values_[i].length() > min_length && title_string_values_[i].length() < max_length) {
                is_similar = check_lcs(title, title_string_values_[i], thre);
                if (is_similar) {
                    //cout << title << endl;
                    //cout << title_string_values_[i] << endl;
                    break;
                }
            }
        }
    }

    if (!is_similar)
    {
        this->add_data(title, title_hash, content_hash);
    }

    return is_similar;
}

void DuplicationChecker::load_hash_data(string file_name)
{
    ifstream input_stream;
    input_stream.open(file_name.c_str());
    if (!input_stream.good())
        return;

    uint64_t title_hash;
    uint64_t content_hash;
    while (!input_stream.eof())
    {
        input_stream >> title_hash;
        input_stream >> content_hash;
        this->title_hash_values_.push_back(title_hash);
        this->content_hash_values_.push_back(content_hash);
    }

    input_stream.close();
}

void DuplicationChecker::load_title_data(string file_name)
{
    ifstream input_stream;
    input_stream.open(file_name.c_str());
    if (!input_stream.good())
        return;

    string title;
    while (!input_stream.eof())
    {
        input_stream >> title;
        this->title_string_values_.push_back(title);
    }

    input_stream.close();
}

void DuplicationChecker::add_data(string title, uint64_t title_hash, uint64_t content_hash)
{
    this->title_string_values_.push_back(title);
    this->title_hash_values_.push_back(title_hash);
    this->content_hash_values_.push_back(content_hash);

    ofstream output_stream;
    output_stream.open(current_hash_file_name_.c_str(), ios::out | ios::app);
    output_stream << title_hash << "\n";
    output_stream << content_hash << "\n";
    output_stream.close();

    ofstream output_title_stream;
    output_title_stream.open(current_title_file_name_.c_str(), ios::out | ios::app);
    output_title_stream << title << "\n";
    output_title_stream.close();

}
