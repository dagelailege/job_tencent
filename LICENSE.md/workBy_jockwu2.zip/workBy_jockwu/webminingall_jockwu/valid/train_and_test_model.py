# -*- coding: utf-8 -*-
"""
train_and_test_model



@author: edgarliao
@email: edgarliao@tencent.com
Created on 2017/11/18, please feel free to contact me.
"""
import sys
from svm_model_trainer import SvmModelTrainer
from info_utility import InfoUtility
import random
from xgboostmodel import XgboostTrainer
import csv


def load_file(invalid_file_name,valid_file_name,case_num=6000):
    train = []
    test = []
    num = 0
    row = '1'
    with open(valid_file_name, 'rb') as f:
        while num<case_num:
            row = f.readline().decode('utf-8').replace('\n', '').replace('\r', '')
            if len(row) == 0:
                break
            tokens = row.split('\t')
            if len(tokens) < 3 or len(tokens[1])<100:
                continue
            if num>=5000:
                test.append(tokens)
            else:
                train.append(tokens)
            num += 1
        f.close()
    #print (num,len(train),len(test))
    num=0
    filter = 0
    with open(invalid_file_name, 'rb') as f:
        while num<case_num:
            row = f.readline().decode('utf-8').replace('\n', '').replace('\r', '')
            if len(row) == 0:
                break
            tokens = row.split('\t')
            if len(tokens) < 3 or len(tokens[1])<100:
                continue
            if num>=5000:
                test.append(tokens)
            else:
                train.append(tokens)
            num += 1
        f.close()
    print ("{} train read OK,{} test read OK!!".format(len(train),len(test)))
    return train, test
def load_test_file(file_name = 'F:/nlp/webminingall/src/script/duplicate/data/labeled_content/G公交.csv'):
    test = []
    with open(file_name,'rb') as f:
         for line in f.readlines():
             line = line.decode('utf-8').replace('\n', '').replace('\r', '')
             tokens = line.split('|||')
             if len(tokens) < 4 or len(tokens[2])<100:
                 continue
             new_tokens = []
             new_tokens.append(tokens[1])
             new_tokens.append(tokens[2])
             new_tokens.append('1' if tokens[0] == '有效' else '0')
             test.append(new_tokens)
    return test
def load_test_file_new(file_name = '../dataset_if_valid/test.txt'):
    test = []
    with open(file_name,'rb') as f:
         for line in f.readlines():
             line = line.decode('utf-8').replace('\n', '').replace('\r', '')
             tokens = line.split('\t')
             if len(tokens) < 3:
                 continue
             new_tokens = []
             new_tokens.append(tokens[0])
             new_tokens.append(tokens[1])
             new_tokens.append('1' if tokens[2] == '有效' else '0')
             test.append(new_tokens)
    return test



if __name__ == '__main__':
    #file_names = [u'F道路封闭.csv', u'K道路更新.csv', u'D电子眼.csv', u'G公交.csv', u'T地铁.csv', u'X限号限行.csv']
    #file_names = [u'X限号限行.csv']
    event_types = [u'G公交']
    invalid_file = '../dataset_if_valid/invalid_g_withouthtml.txt'
    valid_file = '../dataset_if_valid/valid_g_withouthtml_badcase.txt'
    scaler_dir = 'scaler/'
    model_dir = 'model/'
    trans_dir = 'transform/'
    case_dir = 'cases/'


    version = '8.0'


    for event_type in event_types:
        #title_model_file = model_dir + event_type + "_" + "title_model_" + version + ".model"
        #title_dict_file = model_dir + event_type + "_" + "title_dict_" + version + ".dict"
        content_model_file = model_dir + event_type + "_" + "xg_content_model_" + version + ".model"
        content_dict_file = model_dir + event_type + "_" + "xg_content_dict_" + version + ".dict"
        scaler_file = scaler_dir + 'xg_content_' + version + '.scaler'
        trans_file = trans_dir + 'xg_content_' + version + '.trans'
        train_data,test_data = load_file(invalid_file,valid_file)
        InfoUtility.print_log("Train and test: " + event_type)
        #test_data = load_test_file_new()
        #print ("{}".format(len(test_data)))
        #SvmModelTrainer.train(train_data, content_model_file,content_dict_file, scaler_dir, trans_dir)
        XgboostTrainer.train(train_data,test_data,content_model_file,content_dict_file, scaler_file, trans_file)
        #XgboostTrainer.test_training_result(test_data, content_model_file, content_dict_file, case_dir, scaler_file, trans_file)
        """
        test_data:测试集合
        content_model_file:内容训练的模型
        content_dict_file:内容训练的模型的dict文件
        case_dir:正确分类和错误分类的case保存的目录
        """
        """
        if len(test_data) > 1:
            case_dir = 'cases/'
            SvmModelTrainer.test_training_result(test_data,
                                                 content_model_file, content_dict_file, case_dir, scaler_dir, trans_dir)
        """
