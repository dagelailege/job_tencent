# -*- coding: utf-8 -*-


import jieba
import sys
import importlib

importlib.reload(sys)


def create_stop_list(file_path):
        stwlist = [line.strip().decode('utf-8')
                   for line in open(file_path, 'rb').readlines()]
        return stwlist

"""
将原始文件中的每一句进行中文分词
原始文件最长的句子词为117个,共718个词
"""
def text_segmentation(infile_path,outfile_path):
    jieba.load_userdict('./user_dict.txt')
    stop_words = create_stop_list('./stopwords.txt')
    with open(outfile_path,'w',encoding='utf-8') as wf:
        with open(infile_path,'rb') as rf:
            max_len = 0
            vac = set()
            for line in rf.readlines():
                new_line = ''
                seg_list = jieba.cut(line)
                i=0
                for word in seg_list:
                    if word not in stop_words:
                        i +=1
                        new_line += word
                        new_line += ' '
                        vac.add(word)
                wf.write(new_line)
                max_len = i if i>max_len else max_len
    print (max_len)
    print (len(vac))
"""
验证标记的原始训练集
验证处理过后准备用来训练的训练集
"""
def varify(train_path):
    i = 1
    with open(train_path,'rb') as f:
        #print (len(f.readlines()))
        for line in f.readlines():
            #line = line.strip().decode('utf-8')
            line = line.decode("utf-8").replace("\n","")
            data = line.split("\t")[0].split(" ")
            label = line.split("\t")[1].split(" ")
            """
            sub1 = "<B-time>"
            sub2 = "<E-time>"
            if line.count(sub1, 0, len(line)) != line.count(sub2, 0, len(line)):
                print (i)

            columns = line.split(" ")
            for column in columns:
                if column == '':
                    print (i)
                    """
            if not len(data) == len(label):
                print (i)
            i+=1

"""
从原始标记变成训练集的BIO标记
"""
def tag_to_bio(jiebafile_path,train_test_path):
    with open(train_test_path,'w',encoding='utf-8') as wf:
        with open(jiebafile_path,'rb') as rf:
            for line in rf.readlines():
                line = line.decode("utf-8").replace("\n","")
                columns = line.split(" ")
                state = 'O'
                label = ''
                first = False
                for column in columns:
                    if '<' not in column:
                        if state == 'O' or not first:
                            if label!='':
                                label += ' '
                            label += state
                            first = True
                        else:
                            if 'time' in state:
                                state = 'I-time'
                            elif 'where' in state:
                                state = 'I-where'
                            else:
                                state = 'I-action'
                            if label!='':
                                label += ' '
                            label += state
                    else:
                        if 'E' in column:
                            state = 'O'
                        elif 'time' in column:
                            state = 'B-time'
                            first = False
                        elif 'where' in column:
                            state = 'B-where'
                            first = False
                        else:
                            state = 'B-action'
                            first = False
                line = line.replace('<B-time> ','')
                line = line.replace(' <E-time>','')
                line = line.replace('<B-where> ','')
                line = line.replace(' <E-where>','')
                line = line.replace('<B-action> ','')
                line = line.replace(' <E-action>','')
                wf.write(line+"\t"+label+"\n")

"""
从原始标记变成训练集的BIO标记
"""
def formal_tag_to_bio(jiebafile_path,train_test_path):
    with open(train_test_path,'w',encoding='utf-8') as wf:
        with open(jiebafile_path,'rb') as rf:
            for line in rf.readlines():
                line = line.decode("utf-8").replace("\n","").replace("\r","")
                columns = line.split(" ")
                label = ''
                find = False
                num = 0
                for column in columns:
                    if '[' not in column and ']' not in column and not find:
                        if label!='':
                            label += ' '
                        label += 'O'
                        continue
                    elif '[' in column and ']' in column:
                        if 'time' in column:
                            state = 'time'
                        elif 'where' in column:
                            state = 'where'
                        else:
                            state = 'action'
                        if label!='':
                            label+=' '
                        label += 'B-{}'.format(state)
                        num =0
                        find = False
                    elif '[' in column:
                        find = True
                        num+=1
                    elif ']' in column:
                        num+=1
                        if 'time' in column:
                            state = 'time'
                        elif 'where' in column:
                            state = 'where'
                        else:
                            state = 'action'
                        if label!='':
                            label+=' '
                        label += 'B-{}'.format(state)
                        for i in range(num-1):
                            label += ' I-{}'.format(state)
                        find = False
                        num = 0
                    else:
                        num+=1
                line = line.replace('[@','')
                line = line.replace('#time*]','')
                line = line.replace('#where*]','')
                line = line.replace('#action*]','')
                #print (line)
                #print (label)
                #print (len(line.split(' ')))
                #print (len(label.split(' ')))
                wf.write(line+"\t"+label+"\n")
                #exit(0)
"""
参赛
"""


infile_path = './dataset_weibo/temp.txt'
jiebafile_path = './dataset_weibo/temp_jieba.txt.ann'
train_test_path = './dataset_weibo/temp_train_test.txt'

#最长句子62个词
text_segmentation(infile_path, jiebafile_path)
#varify(train_test_path)
#formal_tag_to_bio(jiebafile_path,train_test_path)
