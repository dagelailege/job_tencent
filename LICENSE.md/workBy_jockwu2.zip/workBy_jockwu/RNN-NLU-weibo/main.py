# coding=utf-8
# @author: cer
import tensorflow as tf
from data import *
# from model import Model
from model import Model
from my_metrics import *
from tensorflow.python import debug as tf_debug
import numpy as np
import pickle


input_steps = 80                          #句子最大长度
embedding_size = 64                       #词语编码长度
hidden_size = 100                          #LSTM单元权值向量维度
n_layers = 2                                #  未用到
batch_size = 16                             #batch大小
vocab_size = 660                           #词汇表大小根据训练集定的
slot_size = 9                             # slot class num 根据训练集定的 class + 1
#intent_size = 22                            # intent class num 根据训练集定的
epoch_num = 50                              #epoch大小


def get_model():
    model = Model(input_steps, embedding_size, hidden_size, vocab_size, slot_size,
                  epoch_num, batch_size, n_layers)
    model.build()
    return model
def load_file(file_path):
    re = []
    with open(file_path,'rb') as f:
        for line in f.readlines():
            line = line.decode("utf-8")
            re.append(line)
    return re


def train(is_debug=False):
    model = get_model()
    sess = tf.Session()
    if is_debug:
        sess = tf_debug.LocalCLIDebugWrapperSession(sess)
        sess.add_tensor_filter("has_inf_or_nan", tf_debug.has_inf_or_nan)
    sess.run(tf.global_variables_initializer())
    # print(tf.trainable_variables())
    train_data = load_file("dataset_weibo/formal_train_test.txt")
    test_data = load_file("dataset_weibo/formal_train_test.txt")
    #test_data = open("dataset/atis-2.dev.w-intent.iob", "r").readlines()
    #分割成这样[原始句子的词，标注的序列，intent]
    train_data_ed = data_pipeline(train_data)
    test_data_ed = data_pipeline(test_data)
    word2index, index2word, slot2index, index2slot = \
        get_info_from_training_data(train_data_ed)
    #exit(0)
    with open('./word_index_dict/word2index.dict', 'wb') as f:
            pickle.dump(word2index, f, pickle.HIGHEST_PROTOCOL)
    with open('./word_index_dict/slot2index.dict', 'wb') as f:
            pickle.dump(slot2index, f, pickle.HIGHEST_PROTOCOL)
    # print("slot2index: ", slot2index)
    # print("index2slot: ", index2slot)
    #[sin_ix, true_length, sout_ix, intent_ix]
    index_train = to_index(train_data_ed, word2index, slot2index)
    index_test = to_index(test_data_ed, word2index, slot2index)

    acc_most = 0
    for epoch in range(epoch_num):
        mean_loss = 0.0
        train_loss = 0.0
        for i, batch in enumerate(getBatch(batch_size, index_train)):
            # 执行一个batch的训练
            _, loss, decoder_prediction, mask, slot_W = model.step(sess, "train", batch)
            # if i == 0:
            #     index = 0
            #     print("training debug:")
            #     print("input:", list(zip(*batch))[0][index])
            #     print("length:", list(zip(*batch))[1][index])
            #     print("mask:", mask[index])
            #     print("target:", list(zip(*batch))[2][index])
            #     # print("decoder_targets_one_hot:")
            #     # for one in decoder_targets_one_hot[index]:
            #     #     print(" ".join(map(str, one)))
            #     print("decoder_logits: ")
            #     for one in decoder_logits[index]:
            #         print(" ".join(map(str, one)))
            #     print("slot_W:", slot_W)
            #     print("decoder_prediction:", decoder_prediction[index])
            #     print("intent:", list(zip(*batch))[3][index])
            # mean_loss += loss
            train_loss += loss
            # if i % 10 == 0:
            #     if i > 0:
            #         mean_loss = mean_loss / 10.0
            #     print('Average train loss at epoch %d, step %d: %f' % (epoch, i, mean_loss))
            #     mean_loss = 0
        train_loss /= (i + 1)
        print("[Epoch {}] Average train loss: {}".format(epoch, train_loss))

        # 每训一个epoch，测试一次
        pred_slots = []
        slot_accs = []
        for j, batch in enumerate(getBatch(batch_size, index_test)):
            decoder_prediction = model.step(sess, "test", batch)
            decoder_prediction = np.array(decoder_prediction)[0]
            decoder_prediction = np.transpose(decoder_prediction, [1, 0])
            #测试集结果保存
            """
            if epoch == 49:
                with open('./dataset_weibo/test_predict.txt','a',encoding='utf-8') as f:
                    for index in range(len(batch)):
                        sen_len = batch[index][1]
                        f.write("Input Sentence        : {}".format(index_seq2word(batch[index][0], index2word)[:sen_len]))
                        f.write('\n')
                        f.write("Slot Truth            : {}".format(index_seq2slot(batch[index][2], index2slot)[:sen_len]))
                        f.write('\n')
                        f.write("Slot Prediction       : {}".format(index_seq2slot(decoder_prediction[index], index2slot)[:sen_len]))
                        f.write('\n')
            """
            if j == 0:
                index = random.choice(range(len(batch)))
                # index = 0
                sen_len = batch[index][1]
                print("Input Sentence        : ", index_seq2word(batch[index][0], index2word)[:sen_len])
                print("Slot Truth            : ", index_seq2slot(batch[index][2], index2slot)[:sen_len])
                print("Slot Prediction       : ", index_seq2slot(decoder_prediction[index], index2slot)[:sen_len])
            slot_pred_length = list(np.shape(decoder_prediction))[1]
            pred_padded = np.lib.pad(decoder_prediction, ((0, 0), (0, input_steps-slot_pred_length)),
                                     mode="constant", constant_values=0)
            pred_slots.append(pred_padded)
            # print("slot_pred_length: ", slot_pred_length)
            true_slot = np.array((list(zip(*batch))[2]))
            true_length = np.array((list(zip(*batch))[1]))
            true_slot = true_slot[:, :slot_pred_length]
            # print(np.shape(true_slot), np.shape(decoder_prediction))
            # print(true_slot, decoder_prediction)
            slot_acc = accuracy_score(true_slot, decoder_prediction, true_length)
            # print("slot accuracy: {}, intent accuracy: {}".format(slot_acc, intent_acc))
            slot_accs.append(slot_acc)
        pred_slots_a = np.vstack(pred_slots)
        # print("pred_slots_a: ", pred_slots_a.shape)
        true_slots_a = np.array(list(zip(*index_test))[2])[:pred_slots_a.shape[0]]
        # print("true_slots_a: ", true_slots_a.shape)
        if np.average(slot_accs)>acc_most:
            acc_most = np.average(slot_accs)
        print("Slot accuracy for epoch {}: {}".format(epoch, np.average(slot_accs)))
        print("Slot F1 score for epoch {}: {}".format(epoch, f1_for_sequence_batch(true_slots_a, pred_slots_a)))
        #模型保存

        if epoch == 49:
            saver = tf.train.Saver()
            saver.save(sess,"./model/model_{}".format(epoch))
            all_vars = tf.trainable_variables()
            for v in all_vars:
                print (v.name,v.eval(sess))

        #if epoch%50 ==0:
            #saver = tf.train.Saver()
            #saver.save(sess,"./model/model_{}".format(epoch))

    print (acc_most)
"""
def test_data():
    train_data = open("dataset/atis-2.train.w-intent.iob", "r").readlines()
    test_data = open("dataset/atis-2.dev.w-intent.iob", "r").readlines()
    train_data_ed = data_pipeline(train_data)
    test_data_ed = data_pipeline(test_data)
    word2index, index2word, slot2index, index2slot, intent2index, index2intent = \
        get_info_from_training_data(train_data_ed)
    # print("slot2index: ", slot2index)
    # print("index2slot: ", index2slot)
    index_train = to_index(train_data_ed, word2index, slot2index, intent2index)
    index_test = to_index(test_data_ed, word2index, slot2index, intent2index)
    batch = next(getBatch(batch_size, index_test))
    unziped = list(zip(*batch))
    print("word num: ", len(word2index.keys()), "slot num: ", len(slot2index.keys()), "intent num: ",
          len(intent2index.keys()))
    print(np.shape(unziped[0]), np.shape(unziped[1]), np.shape(unziped[2]), np.shape(unziped[3]))
    print(np.transpose(unziped[0], [1, 0]))
    print(unziped[1])
    print(np.shape(list(zip(*index_test))[2]))
"""
def test():
    f = open('dataset_weibo/test_predict_bysavemodel.txt','w',encoding='utf-8')
    with tf.Session() as sess:
        model = get_model()
        new_saver = tf.train.Saver()
        new_saver.restore(sess, tf.train.latest_checkpoint('./model/'))
        """
        all_vars = tf.trainable_variables()
        for v in all_vars:
            print (v.name,v.eval(sess))
        exit(0)
        """

        test_data = load_file("dataset_weibo/temp_jieba.txt")
        test_data_ed = data_pipeline(test_data)
        with open('./word_index_dict/word2index.dict','rb') as f1:
            word2index = pickle.load(f1)
        with open('./word_index_dict/slot2index.dict','rb') as f2:
            slot2index = pickle.load(f2)
        index2word = {v: k for k, v in word2index.items()}
        index2slot = {v: k for k, v in slot2index.items()}
        index_test = to_index(test_data_ed, word2index, slot2index)
        pred_slots = []
        slot_accs = []
        for j, batch in enumerate(getBatch(batch_size, index_test)):
            print ("in")
            decoder_prediction = model.step(sess, "test", batch)
            decoder_prediction = np.array(decoder_prediction)[0]
            decoder_prediction = np.transpose(decoder_prediction, [1, 0])
            for index in range(len(batch)):
                sen_len = batch[index][1]
                f.write("Input Sentence        : {}".format(index_seq2word(batch[index][0], index2word)[:sen_len]))
                f.write('\n')
                f.write("Slot Truth            : {}".format(index_seq2slot(batch[index][2], index2slot)[:sen_len]))
                f.write('\n')
                f.write("Slot Prediction       : {}".format(index_seq2slot(decoder_prediction[index], index2slot)[:sen_len]))
                f.write('\n')
            if j == 0:
                index = random.choice(range(len(batch)))
                # index = 0
                sen_len = batch[index][1]
                print("Input Sentence        : ", index_seq2word(batch[index][0], index2word)[:sen_len])
                print("Slot Truth            : ", index_seq2slot(batch[index][2], index2slot)[:sen_len])
                print("Slot Prediction       : ", index_seq2slot(decoder_prediction[index], index2slot)[:sen_len])
            slot_pred_length = list(np.shape(decoder_prediction))[1]
            pred_padded = np.lib.pad(decoder_prediction, ((0, 0), (0, input_steps-slot_pred_length)),
                                     mode="constant", constant_values=0)
            pred_slots.append(pred_padded)
            # print("slot_pred_length: ", slot_pred_length)
            true_slot = np.array((list(zip(*batch))[2]))
            true_length = np.array((list(zip(*batch))[1]))
            true_slot = true_slot[:, :slot_pred_length]
            # print(np.shape(true_slot), np.shape(decoder_prediction))
            # print(true_slot, decoder_prediction)
            slot_acc = accuracy_score(true_slot, decoder_prediction, true_length)
            # print("slot accuracy: {}, intent accuracy: {}".format(slot_acc, intent_acc))
            slot_accs.append(slot_acc)
        print (pred_slots)
        pred_slots_a = np.vstack(pred_slots)
        # print("pred_slots_a: ", pred_slots_a.shape)
        true_slots_a = np.array(list(zip(*index_test))[2])[:pred_slots_a.shape[0]]
        # print("true_slots_a: ", true_slots_a.shape)
        print("Slot accuracy for : {}".format(np.average(slot_accs)))
        print("Slot F1 score for : {}".format(f1_for_sequence_batch(true_slots_a, pred_slots_a)))
    f.close()


if __name__ == '__main__':
    # train(is_debug=True)
    #test_data()
    #train()
    test()
