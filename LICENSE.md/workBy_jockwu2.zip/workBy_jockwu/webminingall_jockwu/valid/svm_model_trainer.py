# -*- coding: utf-8 -*-
"""
svm_model_trainer
@author: edgarliao
@email: edgarliao@tencent.com
Created on 2017/11/18, please feel free to contact me.
"""
import pickle
import os
import numpy as np
from sklearn.externals import joblib
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.svm import SVC

from effectiveness_checker import EffectivenessChecker
from jieba_count_vectorizer import JiebaCountVectorizer
from sklearn.model_selection import GridSearchCV

from sklearn.preprocessing import StandardScaler

class SvmModelTrainer:

    def __init__(self):
        self.name = 'SVM Model Trainer'

    @staticmethod
    def train_model(data, label, model_file, dict_file, scaler_dir, trans_dir):
        #构建词频矩阵，a[i][j]表示j词在第i个文本中的词频
        count_vect = JiebaCountVectorizer(binary=False, max_features=50000, max_df=0.7, min_df=10)
        #count_vect = JiebaCountVectorizer(binary=False, max_features=50000)
        content_word_vec = count_vect.fit_transform(data)
        #自动生成的词汇表
        vacab = count_vect.vocabulary_

        with open(dict_file, 'wb',encoding='utf-8') as f:
            pickle.dump(vacab, f, 2)
            f.close()
        #构建TFIDF权值特征,矩阵shape:行为data行数，也就是训练集个数，列为词汇表大小
        transformer = TfidfTransformer().fit(content_word_vec)
        with open(trans_dir + "content.trans", 'wb') as f:
            pickle.dump(transformer,f,2)
        data_tf = transformer.transform(content_word_vec).todense()
        #parameters = {'C': [1e-3, 1e-2, 1e-1, 1, 10, 100, 1000], 'tol': [1e-3, 1e-5, 1e-8], 'gamma': [0.001, 0.0001],
        #               'kernel': ['rbf'], 'probability': [True]}
        #clf = GridSearchCV(SVC(), parameters, scoring='precision')
        #标准化
        scaler = StandardScaler()
        scaler.fit(data_tf)
        with open(scaler_dir+"content.scaler", 'wb') as f:
            pickle.dump(scaler,f,2)
        data_tf_std = scaler.transform(data_tf)
        clf = SVC(C=1, tol=1e-8, probability=True)
        clf.fit(data_tf_std, label)
        joblib.dump(clf, model_file)

    @staticmethod
    def train(records, content_model_file, content_dict_file, scaler_dir, trans_dir):
        content_data = []
        content_labels = []
        for r in records:
            if len(r) < 3:
                continue
            content_data.append(r[1])
            content_labels.append(r[2])
        #test_data = ["您好，这条路现在是开通的，明天大概九点钟可能会封闭".encode("utf-8"),"我是一个测试用例，哈哈哈哈".encode("utf-8"),"我是一个测试用例，哈哈哈哈我是一个测试用例，哈哈哈哈"]
        #SvmModelTrainer.train_model(test_data, title_labels, title_model_file, title_dict_file)
        #SvmModelTrainer.train_model(title_data, title_labels, title_model_file, title_dict_file, scaler_dir, trans_dir)
        SvmModelTrainer.train_model(content_data, content_labels, content_model_file, content_dict_file, scaler_dir, trans_dir)

    @staticmethod
    def test_training_result(test_records,
                             content_model_file, content_dict_file, case_dir, scaler_dir, trans_dir):
        test_titles = []
        test_contents = []
        test_labels = []
        for r in test_records:
            test_labels.append(r[2])
            test_contents.append(r[1])
            test_titles.append(r[0])

        checker = EffectivenessChecker(content_model_file, content_dict_file, scaler_dir, trans_dir)

        tp_output_file = open(case_dir + 'tp_case_content.txt', 'w', encoding='utf-8')
        fn_output_file = open(case_dir + 'fn_case_content.txt', 'w', encoding='utf-8')
        fp_output_file = open(case_dir + 'fp_case_content.txt', 'w', encoding='utf-8')
        tn_output_file = open(case_dir + 'tn_case_content.txt', 'w', encoding='utf-8')
        unsure_output_file = open(case_dir + 'unsure_case_content.txt', 'w', encoding='utf-8')
        tp_count = 0
        tn_count = 0
        fp_count = 0
        fn_count = 0
        tp_count_unsure = 0
        tn_count_unsure = 0
        fp_count_unsure = 0
        fn_count_unsure = 0
        num = 0
        temp = ''
        for i in range(len(test_contents)):
            flag = False
            res, prob = checker.predict(test_contents[i])
            if abs(prob-0.5) < 0.1:
                unsure_output_file.write(
                    (test_titles[i] + '   |||   ' + test_contents[i] + '   |||   '))
                flag = True
            if num%100 ==0:
                print (num)
            num += 1
            if test_labels[i] == '1':
                if res == 1:
                    if flag:
                        tp_count_unsure += 1
                        temp = 'TP'
                    tp_count += 1
                    tp_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
                elif res == 0:
                    if flag:
                        fn_count_unsure += 1
                        temp = 'FN'
                    fn_count += 1
                    fn_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
            elif test_labels[i] == '0':
                if res == 1:
                    if flag:
                        fp_count_unsure += 1
                        temp = 'FP'
                    fp_count += 1
                    fp_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
                elif res == 0:
                    if flag:
                        tn_count_unsure += 1
                        temp = 'TN'
                    tn_count += 1
                    tn_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
            if flag:
                unsure_output_file.write(temp+'\n')
        tp_output_file.close()
        fn_output_file.close()
        fp_output_file.close()
        tn_output_file.close()
        unsure_output_file.close()

        print ("TP: " + str(tp_count) + "    FP: " + str(fp_count))
        print ("FN: " + str(fn_count) + "    TN: " + str(tn_count))
        print ("TP: " + str(tp_count_unsure) + "    FP: " + str(fp_count_unsure))
        print ("FN: " + str(fn_count_unsure) + "    TN: " + str(tn_count_unsure))
        print ('ACC:{}'.format((tp_count+tn_count)/(tp_count+fp_count+tn_count+fn_count)))
        print ('recall:{}'.format((tp_count/(tp_count+fn_count))))
        print ('pre:{}'.format((tp_count/(tp_count+fp_count))))
