import pandas as pd
import numpy as np
import subprocess


filename = './test.csv'

output = './test.txt'

fw = open(output,'w',encoding='utf-8')


with open(filename,'rb') as f:
    line = f.readline()
    while line:
        line = f.readline().decode('utf-8').replace('\r','').replace('\n','')
        columns = line.split(',')
        if len(columns) < 4 or columns[3] == '' or columns[2] == '':
            continue
        re = columns[3]
        title = columns[2]
        url = columns[13]
        cmd = './get_news.sh {}'.format(url)
        content = subprocess.getoutput(cmd)
        print (title,re,content)
        exit(0)
