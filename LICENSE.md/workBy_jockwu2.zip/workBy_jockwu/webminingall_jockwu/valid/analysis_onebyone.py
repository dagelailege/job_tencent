import msvcrt
import pickle

from sklearn.externals import joblib
from sklearn.feature_extraction.text import TfidfTransformer

from jieba_count_vectorizer import JiebaCountVectorizer
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import xgboost as xgb

file = '../dataset_if_valid/valid_g_withouthtml.txt'
new_file = '../dataset_if_valid/valid_g_withouthtml_badcase.txt'
#file = './cases/xgfn_case_content.txt'
content_dict_file = './model/G公交_xg_content_dict_1.0.dict'
content_model_file = './model/G公交_xg_content_model_1.0.model'
scaler_dir = 'scaler/'

trans_dir = 'transform/'


"""
with open(content_dict_file, 'rb') as f:
    vacab = pickle.load(f)
with open(scaler_dir+"xg_content.scaler",'rb') as f:
    scaler = pickle.load(f)
with open(trans_dir+"xg_content.trans",'rb') as f:
    trans = pickle.load(f)
content_vec = JiebaCountVectorizer(binary=False, vocabulary=vacab)
"""
num = 0
bad = 0
fw = open(new_file,'w',encoding='utf-8')
with open(file,'rb') as f:
    line = '1'
    while line:
        line = f.readline()
        num += 1
        """
        if num%1000 == 0:
            print (num)
        if ord(msvcrt.getch()) in [68, 100]:     #按D退出
            break
        """
        line = line.decode('utf-8').replace('\n','')
        tokens = line.split('\t')
        if len(tokens) < 2:
            continue
        title = tokens[0]
        content = tokens[1]
        if '公交' in content or '车' in content or '施工' in content \
            or '交通管制' in content or '路' in content or '巴士' in content or '大巴' in content \
            or '站' in content or len(content)<100:
            fw.write(line+'\n')
            continue
        #label = tokens[2]
        bad += 1
        #print ('------------------------------------------------')
        #content_word_vec = content_vec.fit_transform([content])
        print ("{}************************************************".format(num))
        print (content)
        #content_tf = trans.transform(content_word_vec).todense()
        #content_tf_std = scaler.transform(content_tf)
        #print (label)
    print (bad)

#bst = xgb.Booster({'nthread': 4})  # init model
#bst.load_model(content_model_file)
#fig, ax = plt.subplots(figsize=(12,18))
#xgb.plot_importance(bst, max_num_features=50, height=0.8, ax=ax)
#plt.show()
"""
importance = bst.get_fscore()
with open(content_dict_file, 'rb') as f:
     vacab = pickle.load(f)
vacab_reverse = {v: k for k, v in vacab.items()}
print (len(vacab_reverse))
for k,v in sorted(importance.items(),key = lambda item:item[1]):
    if int(k[1:]) in vacab_reverse:
        print (k,vacab_reverse[int(k[1:])],v)
        """
