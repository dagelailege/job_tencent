from distutils.core import setup, Extension
from Cython.Build import cythonize

setup(ext_modules = cythonize(Extension(
           "PyDuplicationChecker",                                # the extension name
           sources=["PyDuplicationChecker.pyx", "DuplicationChecker.cpp"], # the Cython source and
                                                  # additional C++ source files
           include_dirs=['/data/qqmap/infocollect/script/utility_cpp/PyDuplicationChecker/include'],
           language="c++",                        # generate and compile C++ code
      )))
