#ifndef DUPLICATIONCHECKER_H
#define DUPLICATIONCHECKER_H

#include <string>
#include <vector>
#include <fstream>
using namespace std;
#include "Simhasher.hpp"

class DuplicationChecker
{
    public:
        DuplicationChecker();
        virtual ~DuplicationChecker();
        DuplicationChecker& operator=(const DuplicationChecker& checker);

        void load_all_data(vector<string> hist_hash_files, string current_hash_file, vector<string> hist_title_files, string current_title_file);
        bool check_similarity(string& title, string& content, float thre = 0.85, int min_length = 30, int max_length = 100, int source=1);

    protected:
        vector<string> hist_hash_file_names_;
        string current_hash_file_name_;
        vector<string> hist_title_file_names_;
        string current_title_file_name_;

    private:
        vector<uint64_t> content_hash_values_;
        vector<uint64_t> title_hash_values_;
        vector<string> title_string_values_;
        vector<vector<int> > counter_;

        simhash::Simhasher* sim_hasher_;

        void load_hash_data(string file_name);
        void load_title_data(string file_name);
        void add_data(string title, uint64_t title_hash, uint64_t content_hash);
        bool check_lcs(string first, string second, float thre);
};

#endif // DUPLICATIONCHECKER_H
