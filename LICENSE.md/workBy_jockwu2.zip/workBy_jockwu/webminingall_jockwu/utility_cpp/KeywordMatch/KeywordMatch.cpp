#include "KeywordMatch.h"
#include <algorithm>
#include <sstream>
#include <fstream>
#include <iostream>

// trim from start (in place)
static inline void ltrim(string &s) {
    char ch = s.at(0);
    while (isspace(ch) || ch == '\t' || ch == '\r' || ch == '\n')
    {
        s.erase(s.begin(), s.begin() + 1);
        ch = s.at(0);
    }
//    s.erase(s.begin(), find_if(s.begin(), s.end(), [](int ch) {
//        return !(isspace(ch) || ch == '\t' || ch == '\r' || ch == '\n');
//    }));
}

// trim from end (in place)
static inline void rtrim(string &s) {
    char ch = s.at(s.length() - 1);
    while (isspace(ch) || ch == '\t' || ch == '\r' || ch == '\n')
    {
        s.erase(s.end() - 1, s.end());
        ch = s.at(s.length() - 1);
    }
//    s.erase(find_if(s.rbegin(), s.rend(), [](int ch) {
//        return !(isspace(ch) || ch == '\t' || ch == '\r' || ch == '\n');
//    }).base(), s.end());
}

// trim from both ends (in place)
static inline void trim(string &s) {
    ltrim(s);
    rtrim(s);
}

template<typename Out>
void split(const string &s, char delim, Out result) {
    stringstream ss;
    ss.str(s);
    string item;
    while (getline(ss, item, delim)) {
        trim(item);
        *(result++) = item;
    }
}

vector<string> split(const string &s, char delim) {
    vector<string> elems;
    split(s, delim, back_inserter(elems));
    return elems;
}

KeywordMatch::KeywordMatch()
{
    //ctor
}

KeywordMatch::~KeywordMatch()
{
    //dtor
}

void KeywordMatch::load_event_keywords(string& file_name)
{
    ifstream input_stream;
    input_stream.open(file_name.c_str());
    if (!input_stream.good())
        return;

    string keyword_record;
    getline(input_stream, keyword_record);

    while (!input_stream.eof())
    {
        getline(input_stream, keyword_record);
        vector<string> res = split(keyword_record, ',');
        if (res.size() != 3) continue;
        vector<string> temp_words = split(res[0], ' ');
        if (event_keywords_.find(res[2]) == event_keywords_.end())
        {
            event_keywords_.insert(map<string, vector<vector<string> > >::value_type(res[2], vector<vector<string> >()));
        }
        vector<string> info_record;
        info_record.push_back(res[1]);
        info_record.push_back(res[0]);
        for (int i = 0; i < temp_words.size(); ++i)
        {
            info_record.push_back(temp_words[i]);
        }

        event_keywords_[res[2]].push_back(info_record);
    }

    input_stream.close();
}

vector<vector<string> > KeywordMatch::match_events(string& title)
{
    vector<vector<string> > res;

    map<string, vector<vector<string> > >::iterator iter = this->event_keywords_.begin();
    while (iter != this->event_keywords_.end())
    {
        vector<vector<string> >& keywords = iter->second;
        bool is_match = true;
        string matched_keyword = "";
        string priority = "3";

        for (size_t i = 0; i < keywords.size(); ++i)
        {
            is_match = true;
            for (size_t j = 2; j < keywords[i].size(); ++j)
            {
                is_match = is_match && (title.find(keywords[i][j]) != string::npos);
            }

            if (is_match && keywords[i][0].compare(priority) < 0)
            {
                matched_keyword = keywords[i][1];
                priority = keywords[i][0];
            }
        }
        if (matched_keyword != "")
        {
            vector<string> temp_record;
            temp_record.push_back(iter->first);
            temp_record.push_back(matched_keyword);
            temp_record.push_back(priority);

            res.push_back(temp_record);
        }

        iter++;
    }

    return res;
}
