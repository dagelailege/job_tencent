from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import defaultdict
from sklearn.feature_extraction.text import _make_int_array, frombuffer_empty
import scipy.sparse as sp
import numpy as np
import jieba
import jieba.analyse


class JiebaCountVectorizer(CountVectorizer):

    def JiebaCountVectorizer(self, input='content', encoding='utf-8',
                 decode_error='strict', strip_accents=None,
                 lowercase=True, preprocessor=None, tokenizer=None,
                 stop_words=None, token_pattern=r"(?u)\b\w\w+\b",
                 ngram_range=(1, 1), analyzer='word',
                 max_df=1.0, min_df=1, max_features=None,
                 vocabulary=None, binary=False, dtype=np.int64):
        CountVectorizer.__init__(input, encoding, decode_error, strip_accents, lowercase, preprocessor, tokenizer,
                                 stop_words, token_pattern, ngram_range, analyzer, max_df, min_df, max_features,
                                 vocabulary, binary, dtype)

    def create_stop_list(self, file_path):
        stwlist = [line.strip().decode('utf-8')
                   for line in open(file_path, 'rb').readlines()]
        return stwlist

    def _count_vocab(self, raw_documents, fixed_vocab):
        """Create sparse feature matrix, and vocabulary where fixed_vocab=False
        """

        if fixed_vocab:
            vocabulary = self.vocabulary_
        else:
            # Add a new value when a new vocabulary item is seen
            vocabulary = defaultdict()
            vocabulary.default_factory = vocabulary.__len__

        # jieba.analyse.set_stop_words("E:/webmining/src/script/duplicate/data/stopwords.txt")
        stop_list = self.create_stop_list('./stopwords.txt')
        jieba.load_userdict('./user_dict.txt')
        j_indices = []
        indptr = _make_int_array()
        values = _make_int_array()
        indptr.append(0)
        for doc in raw_documents:
            feature_counter = {}
            #all_feature = ''
            for feature in jieba.cut(doc):
                if feature in stop_list:
                    continue
                if feature.isdigit():
                    continue
                try:
                    #all_feature += '{} '.format(feature)
                    feature_idx = vocabulary[feature]
                    if feature_idx not in feature_counter:
                        feature_counter[feature_idx] = 1
                    else:
                        feature_counter[feature_idx] += 1
                except KeyError:
                    # Ignore out-of-vocabulary items for fixed_vocab=True
                    continue
            #print (all_feature)
            j_indices.extend(feature_counter.keys())
            values.extend(feature_counter.values())
            indptr.append(len(j_indices))

        if not fixed_vocab:
            # disable defaultdict behaviour
            vocabulary = dict(vocabulary)
            if not vocabulary:
                raise ValueError("empty vocabulary; perhaps the documents only"
                                 " contain stop words")

        j_indices = np.asarray(j_indices, dtype=np.intc)
        indptr = np.frombuffer(indptr, dtype=np.intc)
        values = frombuffer_empty(values, dtype=np.intc)

        X = sp.csr_matrix((values, j_indices, indptr),
                          shape=(len(indptr) - 1, len(vocabulary)),
                          dtype=self.dtype)
        X.sort_indices()
        return vocabulary, X
