# -*- coding: utf-8 -*-
"""
svm_model_trainer
@author: edgarliao
@email: edgarliao@tencent.com
Created on 2017/11/18, please feel free to contact me.
"""
import pickle
import os
import numpy as np
from sklearn.externals import joblib
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.svm import SVC

import xgboost as xgb
from xgboost import XGBClassifier

from effectiveness_checker import EffectivenessChecker
from jieba_count_vectorizer import JiebaCountVectorizer
from sklearn.model_selection import GridSearchCV

from sklearn.preprocessing import StandardScaler
import operator


class XgboostTrainer:

    def __init__(self):
        self.name = 'XGboost Model Trainer'

    @staticmethod
    def train_model(train_data, train_label, test_data, test_label, model_file, dict_file, scaler_file, trans_file):
        #构建词频矩阵，a[i][j]表示j词在第i个文本中的词频
        train_count_vect = JiebaCountVectorizer(binary=False, max_features=50000, max_df=0.7, min_df=10)
        #count_vect = JiebaCountVectorizer(binary=False, max_features=50000)
        train_content_word_vec = train_count_vect.fit_transform(train_data)
        #自动生成的词汇表
        vacab = train_count_vect.vocabulary_
        test_content_vec = JiebaCountVectorizer(binary=False, vocabulary=vacab)

        test_content_word_vec = test_content_vec.fit_transform(test_data)
        with open(dict_file, 'wb') as f:
            pickle.dump(vacab, f, 2)
            f.close()
        #构建TFIDF权值特征,矩阵shape:行为data行数，也就是训练集个数，列为词汇表大小
        transformer = TfidfTransformer().fit(train_content_word_vec)
        with open(trans_file, 'wb') as f:
            pickle.dump(transformer,f,2)
        train_data_tf = transformer.transform(train_content_word_vec).todense()
        test_data_tf = transformer.transform(test_content_word_vec).todense()
        #parameters = {'C': [1e-3, 1e-2, 1e-1, 1, 10, 100, 1000], 'tol': [1e-3, 1e-5, 1e-8], 'gamma': [0.001, 0.0001],
        #               'kernel': ['rbf'], 'probability': [True]}
        #clf = GridSearchCV(SVC(), parameters, scoring='precision')
        #标准化
        scaler = StandardScaler()
        scaler.fit(train_data_tf)
        with open(scaler_file, 'wb') as f:
            pickle.dump(scaler,f,2)
        train_data_tf_std = scaler.transform(train_data_tf)
        test_data_tf_std = scaler.transform(test_data_tf)
        dtrain = xgb.DMatrix(train_data_tf_std, label=train_label)
        dtest = xgb.DMatrix(test_data_tf_std, label=test_label)
        #etas = [0.3]
        #max_depths = [6]
        #subsamples =[1]
        #colsample_bytrees = [1]
        #num_rounds = [24]
        """
        etas = [0.01,0.05,0.1,0.3,0.5]
        max_depths = [3,4,5,6,7]
        subsamples = [0.5,0.8,1]
        colsample_bytrees = [0.5,0.8,1]
        max_score = 0
        max_iteration = 0
        max_para = {}
        """
        """
        param_test = { #弱分类器的数目以及范围

        'eta': etas,'max_depth': max_depths,
        'subsample': subsamples,
        'colsample_bytree': colsample_bytrees,
        'num_round': num_rounds

        }
        bst = XGBClassifier(silent=False, objective='binary:logistic')
        clt = GridSearchCV(estimator = bst, param_grid = param_test, scoring='accuracy', cv=5)
        clf.fit(train_data_tf_std, train_label)
        print (clf.grid_scores_, clf.best_params_, clf.best_score_)
        """
        param = {'max_depth': 7, 'eta': 0.05, 'silent': 0, 'objective': 'binary:logistic', 'subsample': 0.8, 'colsample_bytree': 0.8}
        #param = {'max_depth': 7, 'eta': 0.05, 'silent': 0, 'objective': 'binary:logistic', 'subsample': 1, 'colsample_bytree': 1}
        param['nthread'] = 6
        param['eval_metric'] = 'error'
        num_round = 1000
        plst = param.items()
        evallist = [(dtest, 'eval')]
        bst = xgb.train(plst, dtrain, num_round,evallist,early_stopping_rounds=80)
        bst.save_model(model_file)
        """
        num = 0
        for eta in etas:
            for max_depth in max_depths:
                for subsample in subsamples:
                    for colsample_bytree in colsample_bytrees:
                        num += 1
                        print ('{} tested!'.format(num))
                        #num = 86 0.072
                        if num<86:
                            continue


                        param = {'max_depth': max_depth, 'eta': eta, 'silent': 0, 'objective': 'binary:logistic','subsample':subsample,'colsample_bytree':colsample_bytree}
                        print (param)
                        exit(0)
                        param['nthread'] = 6
                        param['eval_metric'] = 'error'
                        num_round = int((1/eta)*24)
                        plst = param.items()
                        evallist = [(dtest, 'eval')]
                        bst = xgb.train(plst, dtrain, num_round,evallist,early_stopping_rounds=15)
                        #bst.best_score, bst.best_iteration and bst.best_ntree_limit
                        if max_score<bst.best_score:
                            max_score = bst.best_score
                            max_para = param
                            max_iteration = bst.best_iteration
                            bst.save_model(model_file)


        print (max_score)
        print (max_iteration)
        print (max_para)
    """
    @staticmethod
    def train(train_records, test_records, content_model_file, content_dict_file, scaler_file, trans_file):
        train_data = []
        train_label = []
        for r in train_records:
            if len(r) < 3:
                continue
            train_data.append(r[0] + "。" + r[1])
            train_label.append(r[2])
        test_data = []
        test_label = []
        for r in test_records:
            if len(r) < 3:
                continue
            test_data.append(r[0] + "。" + r[1])
            test_label.append(r[2])
        #test_data = ["您好，这条路现在是开通的，明天大概九点钟可能会封闭".encode("utf-8"),"我是一个测试用例，哈哈哈哈".encode("utf-8"),"我是一个测试用例，哈哈哈哈我是一个测试用例，哈哈哈哈"]
        #SvmModelTrainer.train_model(test_data, title_labels, title_model_file, title_dict_file)
        #SvmModelTrainer.train_model(title_data, title_labels, title_model_file, title_dict_file, scaler_dir, trans_dir)
        XgboostTrainer.train_model(train_data, train_label, test_data, test_label, content_model_file, content_dict_file, scaler_file, trans_file)

    @staticmethod
    def test_training_result(test_records,
                             content_model_file, content_dict_file, case_dir, scaler_file, trans_file):
        test_titles = []
        test_contents = []
        test_labels = []
        for r in test_records:
            test_labels.append(r[2])
            test_contents.append(r[0]+"。"+r[1])
            test_titles.append(r[0])
        with open(content_dict_file, 'rb') as f:
            vacab = pickle.load(f)
        with open(scaler_file,'rb') as f:
            scaler = pickle.load(f)
        with open(trans_file,'rb') as f:
            trans = pickle.load(f)
        print (len(vacab))
        test_content_vec = JiebaCountVectorizer(binary=False, vocabulary=vacab)
        test_content_word_vec = test_content_vec.fit_transform(test_contents)
        test_data_tf = trans.transform(test_content_word_vec).todense()
        test_data_tf_std = scaler.transform(test_data_tf)
        dtest = xgb.DMatrix(test_data_tf_std)
        bst = xgb.Booster({'nthread': 4})  # init model
        bst.load_model(content_model_file)  # load data
        """
        #show the importance of the word
        importance = bst.get_fscore()
        importance = sorted(importance.items(), key=operator.itemgetter(1))
        print (importance)
        eixt(0)
        """
        ypred = bst.predict(dtest)
        tp_output_file = open(case_dir + 'xgtp_case_content.txt', 'w', encoding='utf-8')
        fn_output_file = open(case_dir + 'xgfn_case_content.txt', 'w', encoding='utf-8')
        fp_output_file = open(case_dir + 'xgfp_case_content.txt', 'w', encoding='utf-8')
        tn_output_file = open(case_dir + 'xgtn_case_content.txt', 'w', encoding='utf-8')
        tp_count = 0
        tn_count = 0
        fp_count = 0
        fn_count = 0
        num = 0
        for i in range(len(test_contents)):
            if num%100 ==0:
                print (num)
            num += 1
            if test_labels[i] == '1':
                if ypred[i] >= 0.5:
                    tp_count += 1
                    tp_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
                elif ypred[i] < 0.5:
                    fn_count += 1
                    fn_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
            elif test_labels[i] == '0':
                if ypred[i] >= 0.5:
                    fp_count += 1
                    fp_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
                elif ypred[i] < 0.5:
                    tn_count += 1
                    tn_output_file.write(
                        (test_titles[i] + '   |||   ' + test_contents[i] + '\n'))
        tp_output_file.close()
        fn_output_file.close()
        fp_output_file.close()
        tn_output_file.close()

        print ("TP: " + str(tp_count) + "    FP: " + str(fp_count))
        print ("FN: " + str(fn_count) + "    TN: " + str(tn_count))
        print ('ACC:{}'.format((tp_count+tn_count)/(tp_count+fp_count+tn_count+fn_count)))
        print ('recall:{}'.format((tp_count/(tp_count+fn_count))))
        print ('pre:{}'.format((tp_count/(tp_count+fp_count))))
