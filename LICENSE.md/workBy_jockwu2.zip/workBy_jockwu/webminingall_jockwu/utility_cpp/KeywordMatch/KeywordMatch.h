#ifndef KEYWORDMATCH_H
#define KEYWORDMATCH_H

#include <map>
#include <vector>
#include <string>
using namespace std;

class KeywordMatch
{
    public:
        KeywordMatch();
        void load_event_keywords(string& file_name);
        virtual ~KeywordMatch();

        vector<vector<string> > match_events(string& title);

    protected:

    private:
        map<string, vector<vector<string> > > event_keywords_;
};

#endif // KEYWORDMATCH_H
