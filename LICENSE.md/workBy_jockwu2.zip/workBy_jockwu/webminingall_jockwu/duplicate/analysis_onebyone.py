import msvcrt



file_path = './duplicate_case/simhash_m.txt'

with open(file_path,'rb') as f:
    while 1:
        line = '1'
        while line!="":
            line = f.readline().decode('utf-8').replace('\n','').replace('\r','')
            print (line)
        if ord(msvcrt.getch()) in [68, 100]:
            break
