# -*- coding: utf-8 -*-
"""
transform txt to csv



@author: jockwu
@email: jockwu@tencent.com
Created on 2018/05/18, please feel free to contact me.
"""
import sys
import codecs
from pyquery import PyQuery


input_file = './dataset_if_valid/invalid_g.txt'
output_file = './dataset_if_valid/invalid_g_withouthtml.txt'




with open(input_file,'rb') as f:
    fw = open(output_file, "w",encoding='utf-8')
    line = f.readline()
    num = 0
    while line:
        line = f.readline()
        line = line.decode('utf-8')
        #print line
        tokens = line.split("\t")
        if(len(tokens)<3):
            continue
        if tokens[2] == 'NULL' or len(tokens[2])<10:
            continue
        try:
            code = PyQuery(tokens[0]).text().replace('\t', '').replace('\n', '').replace('\r', '')
            title = PyQuery(tokens[1]).text().replace('\t', '').replace('\n', '').replace('\r', '')
            content = PyQuery(tokens[2]).text().replace('\t', '').replace('\n', '').replace('\r', '')
        except:
            continue
        else:
        #test = "你好"
            label = '0'
            row = title + "\t" + content + "\t" + label +"\n"


            fw.write(row)
            if num%20000 == 0:
                print (num)
            num +=1
    fw.close()
