# -*- coding: utf-8 -*-
"""
info_utility



@author: edgarliao
@email: edgarliao@tencent.com
Created on 2017/8/28, please feel free to contact me.
"""
import re
import datetime
import time
from datetime import date


class InfoUtility:

    DEFAULT_DATE = date(1997, 1, 1)

    def __init__(self):
        self.name = 'Utility'

    @staticmethod
    def print_log(info):
        date_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
        print ("[%s]%s" % (date_time, info))

    @staticmethod
    def get_url_domain(url):
        domain = url.split('/', 3)
        if len(domain) > 2:
            new_url = domain[0] + '//' + domain[2] + '/'
        else:
            new_url = url
        return new_url

    @staticmethod
    def format_clean_string(url_str):
        return url_str.replace(" ", "").replace("\t", "").replace("\r", "").replace("\n", "")

    # 将微信等特定网站，栏目的【】 《》 「」 []   括号及括号内的统一都过滤掉，只这些符号在情报标题头
    @staticmethod
    def format_prefix(url_str):
        string = url_str
        for i in range(1, 5):
            if string.startswith('【') and string.find('】') > -1:
                string = string[string.find('】') + 1: len(string)]
            elif string.startswith('《') and string.find('》') > -1:
                string = string[string.find('》') + 1: len(string)]
            elif string.startswith('「') and string.find('」') > -1:
                string = string[string.find('」') + 1: len(string)]
            elif string.startswith('[') and string.find(']') > -1:
                string = string[string.find(']') + 1: len(string)]
        if len(string) == 0:
            return url_str
        else:
            return string

    @staticmethod
    # deal with patterns like: 4小时前，16小时前，2天前，12天前，2017-09-04，2017/09/04
    def check_date_is_recent(date_string, threshold=2):
        current_date = datetime.date.today()
        try:
            pattern = u'(\d{4})[\-\/\._](\d{2})[\-\/\._](\d{2})'
            m = re.search(pattern, date_string)
            if m:
                info_date = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
                delta_days = (current_date - info_date).days
                if delta_days > threshold:
                    return None
                else:
                    return info_date
        except ValueError:
            pass

        try:
            pattern = u'([\d{1}|\d{2}])小时前'
            m = re.search(pattern, date_string)
            if m:
                hours = int(m.group(1))
                info_date = current_date - datetime.timedelta(days=(hours / 24))
                if hours > threshold * 24:
                    return None
                else:
                    return info_date
        except ValueError:
            pass

        try:
            pattern = u'([\d{1}|\d{2}])天前'
            m = re.search(pattern, date_string)
            if m:
                days = int(m.group(1))
                info_date = current_date - datetime.timedelta(days=days)
                if days > threshold:
                    return None
                else:
                    return info_date
        except ValueError:
            pass

        return InfoUtility.DEFAULT_DATE

    @staticmethod
    def check_url_date_is_recent(date_string, threshold=2):
        # deal with patterns like:
        # 1. 2017/09/04, 2017/9/4, 2017/9/04, 2017/09/4
        # 2. 09/04/2017
        # 3. 201709, 2017/03
        current_date = datetime.datetime.now().date()
        current_year = current_date.year
        best_match_date = InfoUtility.DEFAULT_DATE
        days_num = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]

        try:
            pattern = u'\D{1}(\d{4})[\-\/\._]*(\d{2})[\-\/\._]*(\d{2})\D{1}'
            matcher = re.compile(pattern)
            matches = matcher.findall(date_string)
            for m in matches:
                year = int(m[0])
                if year > current_year or year < 2000:
                    continue
                month = int(m[1])
                if month == 0 or month > 12:
                    continue
                day = int(m[2])
                if day == 0 or day > days_num[month - 1]:
                    continue
                info_date = date(year, month, day)
                if (current_date - best_match_date).days > (current_date - info_date).days:
                    best_match_date = info_date
        except ValueError:
            pass

        try:
            pattern = u'(\D{1})(2\d{3}|([0-1][0-9]))[\-\/\._]*([0-1]?[0-9])([\-\/\._]*)([0-3]?[0-9])(\D{1})'
            matcher = re.compile(pattern)
            matches = matcher.findall(date_string)
            for m in matches:
                if str.isdigit(str(m[6])) or str.isdigit(str(m[0])) or m[6] == '.' or len(m[1] + m[3] + m[5]) <= 4:
                    continue
                if len(m[3]) + len(m[5]) < 3 and len(m[4]) == 0:
                    continue
                year = int(m[1])
                if year < 30:
                    year += 2000
                if year > current_year:
                    continue
                month = int(m[3])
                if month == 0 or month > 12:
                    continue
                day = int(m[5])
                if day == 0 or day > days_num[month - 1]:
                    continue
                info_date = date(year, month, day)
                if (current_date - best_match_date).days > (current_date - info_date).days:
                    best_match_date = info_date

            pattern = u'(\D{1})([0-1]?[1-9])([\-\/\._]*)([0-3]?[0-9])[\-\/\._]*(2\d{3}|([0-1][0-9]))(\D{1})'
            matcher = re.compile(pattern)
            matches = matcher.findall(date_string)
            for m in matches:
                if str.isdigit(str(m[6])) or str.isdigit(str(m[0])) or m[6] == '.' or len(m[1] + m[3] + m[4]) <= 4:
                    continue
                if len(m[1]) + len(m[3]) < 3 and len(m[2]) == 0:
                    continue
                year = int(m[4])
                if year < 30:
                    year += 2000
                if year > current_year:
                    continue
                month = int(m[1])
                if month == 0 or month > 12:
                    continue
                day = int(m[3])
                if day == 0 or day > days_num[month - 1]:
                    continue
                info_date = date(year, month, day)
                if (current_date - best_match_date).days > (current_date - info_date).days:
                    best_match_date = info_date

            if best_match_date.year == InfoUtility.DEFAULT_DATE.year:
                pattern = '(\D{1})(2\d{3})[\-\/\._]*([0-1][0-9])(\D{1})'
                matcher = re.compile(pattern)
                matches = matcher.findall(date_string)
                for m in matches:
                    if str.isdigit(str(m[3])) or str.isdigit(str(m[0])) or m[3] == '.':
                        continue
                    year = int(m[1])
                    if year < 30:
                        year += 2000
                    if year > current_year:
                        continue
                    month = int(m[2])
                    if month == 0 or month > 12:
                        continue
                    day = min(current_date.day, days_num[month - 1])
                    info_date = date(year, month, day)
                    if (current_date - best_match_date).days > (current_date - info_date).days:
                        best_match_date = info_date
        except Exception as e:
            print (e)
            print ('Error pattern: ' + date_string)
            best_match_date = InfoUtility.DEFAULT_DATE

        if (best_match_date - InfoUtility.DEFAULT_DATE).days == 0 \
                or (current_date - best_match_date).days < threshold:
            return best_match_date
        else:
            return None

    # 如果关键词是用空格分割，则需要先split，然后遍历查看是否每个关键词都包含
    @staticmethod
    def check_keyword_contains(text, keyword, split_char):
        if text == '':
            return False
        array = keyword.split(split_char)
        for key in array:
            if text.find(key) == -1:
                return False
        return True
