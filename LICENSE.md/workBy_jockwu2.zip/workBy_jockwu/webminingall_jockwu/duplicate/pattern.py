# -*- coding: utf-8 -*-

import re



class pattern:
    def __init__(self):
        p1 = re.compile('[0-9]+[a-zA-Z]*[路|线]')   #数字+（字母）+路/线
        p2 = re.compile('[a-zA-Z]+[0-9]+[.]*[支线|支|路|线]')  #字母+数字
        p3 = re.compile('[a-zA-Z]+[0-9]+[a-zA-Z]+[路|线]')                                  #字母+数字+字母
        p4 = re.compile('[a-zA-Z]+支[0-9]+[路|线]')            #字母+支+数字+路/线
        self.patterns = [p1,p2,p3,p4]


    def find_all(self,s):
        result = []
        for pattern in self.patterns:
            for substring in pattern.findall(s):
                if substring not in result:
                    result.append(substring)
        return result

    def compare(self,s1,s2):
        r1 = self.find_all(s1)
        r2 = self.find_all(s2)
        if(len(r1)!=len(r2)):
            return False
        else:
            for car in r1:
                if car not in r2:
                    return False
            for car in r2:
                if car not in r1:
                    return False
            return True

if __name__ == '__main__':
    p = pattern()
    print (p.compare("","聊城公交新开通162路和88和A支3线公交车"))
