import ctypes


#lcsLib = ctypes.cdll.LoadLibrary('C:/Users/jockwu/CLionProjects/LCS/lcs.dll')
addLib = ctypes.cdll.LoadLibrary('C:/Users/jockwu/CLionProjects/LCS/add.dll')


#print (lcsLib.Lcs('123sdfa','sdsdf4334'))
print (addLib.myAdd(1,2))
